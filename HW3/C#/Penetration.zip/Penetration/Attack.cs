﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Penetration
{
    internal class Attack
    {
        public List<List<int>> systems = new List<List<int>>();
        private double p = 0.3;

        public Attack(int M, int N)
        {
            for (int i = 0; i < M; i++)
            {
                systems.Add(new List<int>());
                for (int j = 0; j < N; j++)
                {
                    systems[i].Add(0);
                }

            }
        }

        public void generateAttack()
        {
            Random random = new Random();

            for (int i = 0; i < systems[0].Count; i++)
            {
                for (int j = 0; j < systems.Count; j++)
                {
                    var nextRandom = random.NextDouble();
                    this.systems[j][i] = nextRandom <= p ? -1 : 1;
                }
            }
        }

        public List<List<int>> getSystems()
        {
            return this.systems;
        }
    }
}
