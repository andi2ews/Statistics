﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Penetration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Attack attack = new Attack(5, 30);
            attack.generateAttack();

            List<List<int>> systems = attack.getSystems();

            foreach (var s in systems)
            {
                richTextBox1.AppendText("[");
                for (int i = 0; i < s.Count; i++)
                {
                    richTextBox1.AppendText(s[i] + ", ");
                }
                richTextBox1.AppendText("]");
                richTextBox1.AppendText(Environment.NewLine);
            }
    }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
